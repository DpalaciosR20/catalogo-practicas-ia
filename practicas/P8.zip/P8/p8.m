function interfaz_pronostico_clima
    % Crear la ventana principal
    fig = uifigure('Name', 'Pronóstico del Clima', 'Position', [100, 100, 250, 300]);

    uilabel(fig, 'Text', 'Pronóstico del Clima', 'Position', [70, 270, 250, 20], 'FontWeight','bold');

    % Desplegables para las variables
    uilabel(fig, 'Text', 'Humedad:', 'Position', [20, 220, 100, 20]);
    humedadMenu = uidropdown(fig, 'Items', {'alta', 'media', 'baja'}, 'Position', [120, 220, 100, 20]);

    uilabel(fig, 'Text', 'Nubosidad:', 'Position', [20, 180, 100, 20]);
    nubosidadMenu = uidropdown(fig, 'Items', {'densa', 'moderada', 'ligera'}, 'Position', [120, 180, 100, 20]);

    uilabel(fig, 'Text', 'Temperatura:', 'Position', [20, 140, 100, 20]);
    temperaturaMenu = uidropdown(fig, 'Items', {'alta', 'media', 'baja'}, 'Position', [120, 140, 100, 20]);

    % Botón para calcular
    calcularBtn = uibutton(fig, 'Text', 'Calcular', 'Position', [75, 80, 100, 40], ...
        'ButtonPushedFcn', @(btn, event) calcularProbabilidad(humedadMenu, nubosidadMenu, temperaturaMenu));

    % Botón de ayuda
    ayudaBtn = uibutton(fig, 'Text', '?', 'Position', [220, 10, 25, 25], ...
        'BackgroundColor',[0.4,0.63,1],...
        'FontColor',[0.87,0.87,0.87],...
        'FontWeight', 'bold',...
        'ButtonPushedFcn', @(btn, event) mostrarAyuda());

    % Etiqueta para mostrar resultados
    resultadoLabel = uilabel(fig, 'Text', '', 'Position', [0, 40, 250, 20], 'HorizontalAlignment', 'center');
    
    % Función de cálculo
    function calcularProbabilidad(humedadMenu, nubosidadMenu, temperaturaMenu)
        humedad = char(humedadMenu.Value);
        nubosidad = char(nubosidadMenu.Value);
        temperatura = char(temperaturaMenu.Value);

        prob_lluvia = pronostico_clima(humedad, nubosidad, temperatura);
        resultadoLabel.Text = sprintf('Probabilidad de lluvia: %.2f%%', prob_lluvia * 100);
    end

    % Función de ayuda
    function mostrarAyuda()
        % Crear ventana de ayuda
        ayudaFig = uifigure('Name', 'Ayuda', 'Position', [150, 150, 420, 300]);
        
        % Texto de ayuda
        ayudaText = [
            "Este programa calcula la probabilidad de lluvia basada en tres factores:"
            " - Humedad: Puede ser alta, media o baja."
            " - Nubosidad: Puede ser densa, moderada o ligera."
            " - Temperatura: Puede ser alta, media o baja."
            ""
            "Cálculo de la probabilidad:"
            "  El programa usa el Teorema de Bayes para combinar las probabilidades"
            "  individuales de cada factor, determinando la probabilidad conjunta"
            "  de que llueva dado el estado de las variables seleccionadas."
            ""
        ];
        
        uilabel(ayudaFig, 'Text', strjoin(ayudaText, '\n'), 'Position', [20, 20, 400, 260], ...
            'HorizontalAlignment', 'left', 'VerticalAlignment', 'top');

        % Cargar y mostrar la imagen
        ax = axes(ayudaFig, 'Position', [0.1 0.1 0.8 0.4]);  % Área donde se mostrará la imagen
        img = imread('img.png');  % Asegúrate de poner la ruta correcta a tu imagen
        imshow(img, 'Parent', ax);
    end
end

function prob_lluvia = pronostico_clima(humedad, nubosidad, temperatura)
    % Valores predeterminados si no se proporcionan argumentos
    if nargin < 3
        humedad = 'media';
        nubosidad = 'moderada';
        temperatura = 'media';
    end

    % Probabilidades iniciales
    P_lluvia = 0.3;
    P_no_lluvia = 0.7;

    % Probabilidades condicionales
    P_humedad_dada_lluvia = [0.8, 0.6, 0.2]; 
    P_humedad_dada_no_lluvia = [0.3, 0.4, 0.7];

    P_nubosidad_dada_lluvia = [0.9, 0.7, 0.4];
    P_nubosidad_dada_no_lluvia = [0.2, 0.5, 0.8];

    P_temperatura_dada_lluvia = [0.4, 0.5, 0.7];
    P_temperatura_dada_no_lluvia = [0.7, 0.5, 0.2];

    % Índices de las categorías
    humedad_idx = find(strcmp(humedad, {'alta', 'media', 'baja'}));
    nubosidad_idx = find(strcmp(nubosidad, {'densa', 'moderada', 'ligera'}));
    temperatura_idx = find(strcmp(temperatura, {'alta', 'media', 'baja'}));

    % Cálculo de probabilidades conjuntas
    P_dados_lluvia = P_humedad_dada_lluvia(humedad_idx) * ...
                     P_nubosidad_dada_lluvia(nubosidad_idx) * ...
                     P_temperatura_dada_lluvia(temperatura_idx);

    P_dados_no_lluvia = P_humedad_dada_no_lluvia(humedad_idx) * ...
                        P_nubosidad_dada_no_lluvia(nubosidad_idx) * ...
                        P_temperatura_dada_no_lluvia(temperatura_idx);

    % Teorema de Bayes
    P_lluvia_dados = P_dados_lluvia * P_lluvia / ...
                     (P_dados_lluvia * P_lluvia + P_dados_no_lluvia * P_no_lluvia);

    prob_lluvia = P_lluvia_dados;
end
