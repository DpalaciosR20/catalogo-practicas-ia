function SlotFillingApp()
    % Crear la ventana de la interfaz
    app.Fig = uifigure('Position', [500, 300, 400, 300], 'Name', 'Slot Filling App');
    
    % Campo de texto para la frase de entrada
    uilabel(app.Fig, 'Text', 'Ingrese la frase:', 'Position', [20, 230, 100, 20]);
    app.InputField = uieditfield(app.Fig, 'text', 'Position', [130, 230, 230, 30]);
    
    % Botón para procesar la frase
    app.ProcessButton = uibutton(app.Fig, 'push', ...
        'Text', 'Procesar', ...
        'Position', [150, 180, 100, 30], ...
        'ButtonPushedFcn', @(btn, event) processInput(app));
    
    % Etiquetas para los resultados
    uilabel(app.Fig, 'Text', 'Origen:', 'Position', [20, 130, 60, 20]);
    app.OriginLabel = uilabel(app.Fig, 'Text', 'No encontrado', 'Position', [100, 130, 200, 20]);

    uilabel(app.Fig, 'Text', 'Destino:', 'Position', [20, 100, 60, 20]);
    app.DestinationLabel = uilabel(app.Fig, 'Text', 'No encontrado', 'Position', [100, 100, 200, 20]);

    uilabel(app.Fig, 'Text', 'Fecha:', 'Position', [20, 70, 60, 20]);
    app.DateLabel = uilabel(app.Fig, 'Text', 'No encontrado', 'Position', [100, 70, 200, 20]);

    % Mostrar la ventana
    movegui(app.Fig, 'center');
end

function processInput(app)
    % Obtener la frase ingresada por el usuario
    sentence = app.InputField.Value;

    % Definir patrones para extraer ranuras
    patron_origen = '(de|desde)\s([\w\s]+)\s(a)';
    patron_destino = '(a)\s([\w\s]+)\s(el|para|por)';
    patron_fecha = '(el|para|por)\s(\d{1,2}\sde\s\w+)';

    % Buscar coincidencias usando expresiones regulares
    [~, ~, ~, grupos_origen] = regexp(sentence, patron_origen, 'match', 'tokens');
    [~, ~, ~, grupos_destino] = regexp(sentence, patron_destino, 'match', 'tokens');
    [~, ~, ~, grupos_fecha] = regexp(sentence, patron_fecha, 'match', 'tokens');

    % Inicializar las variables
    origen = 'No encontrado';
    destino = 'No encontrado';
    fecha = 'No encontrado';

    % Verificar y asignar el origen
    if iscell(grupos_origen) && ~isempty(grupos_origen) && numel(grupos_origen{1}) >= 2
        origen = strtrim(grupos_origen{1}{2}); % Extrae el origen
    end

    % Verificar y asignar el destino
    if iscell(grupos_destino) && ~isempty(grupos_destino) && numel(grupos_destino{1}) >= 2
        destino = strtrim(grupos_destino{1}{2}); % Extrae el destino
    end

    % Verificar y asignar la fecha
    if iscell(grupos_fecha) && ~isempty(grupos_fecha) && numel(grupos_fecha{1}) >= 2
        fecha = strtrim(grupos_fecha{1}{2}); % Extrae la fecha
    end

    % Actualizar las etiquetas en la interfaz
    app.OriginLabel.Text = origen;
    app.DestinationLabel.Text = destino;
    app.DateLabel.Text = fecha;
end
    