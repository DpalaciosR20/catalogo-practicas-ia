% Frase de ejemplo
oracion = 'Quiero volar de Nueva York a París el 20 de noviembre';
% Definimos patrones básicos para reconocer origen, destino y fecha
patron_origen = '(de|desde)\s([\w\s]+)\s(a)';
patron_destino = '(a)\s([\w\s]+)\s(el|para|el)';
 patron_fecha = '(el|para)\s(\d{1,2}\sde\s\w+)';

 % Buscamos coincidencias usando expresiones regulares
 [~, ~, ~, grupos_origen] = regexp(oracion, patron_origen, 'tokens');
 [~, ~, ~, grupos_destino] = regexp(oracion, patron_destino,'tokens');
 [~, ~, ~, grupos_fecha] = regexp(oracion, patron_fecha, 'tokens');

 
 % Asignamos valores a las ranuras
 if ~isempty(grupos_origen)
 origen = strtrim(grupos_origen{1}{2}); % Extrae el origen
 else
 origen = 'No encontrado';
 end

 if ~isempty(grupos_destino)
 %destino = strtrim(grupos_destino{1}{2}); % Extrae el destino
 else
 destino = 'No encontrado';
 end

if ~isempty(grupos_fecha)
 %fecha = strtrim(grupos_fecha{1}{2}); % Extrae la fecha
 else
 fecha = 'No encontrado';
 end

 % Mostramos los resultados
 fprintf('Origen: %s\n', origen);
 fprintf('Destino: %s\n', destino);
 fprintf('Fecha: %s\n', fecha);