% Definir la matriz de adyacencia (grafo)
nodos = 6; % Número de nodos
A = [0 1 4 inf inf inf;
     1 0 2 6 inf inf;
     4 2 0 3 3 inf;
     inf 6 3 0 2 5;
     inf inf 3 2 0 2;
     inf inf inf 5 2 0];
% Definir los puntos de los nodos (para la heurística, puede ser una distancia euclidiana)
coordenadas = [0 0;
               1 1;
               2 2;
               3 2;
               4 3;
               5 3];
% Definir el nodo de inicio y objetivo
inicio = 1;
objetivo = 6;

% Función heurística (distancia euclidiana a la meta)
function h = heuristica(nodo, objetivo, coordenadas)
    h = norm(coordenadas(nodo,:) - coordenadas(objetivo,:));
end

% Algoritmo A*
function [camino, costo_total] = A_star(A, inicio, objetivo, coordenadas)
    nodos = size(A, 1);
    % Inicializar costos y listas
    g = inf(1, nodos); % Costo desde el inicio a cada nodo
    f = inf(1, nodos); % Costo estimado total (g + h)
    g(inicio) = 0;
    f(inicio) = heuristica(inicio, objetivo, coordenadas);
    % Lista abierta (nodos por explorar) y cerrada (ya explorados)
    abierta = [inicio];
    cerrada = [];
    % Predecesores (para construir el camino final)
    predecesor = zeros(1, nodos);
    while ~isempty(abierta)
        % Encontrar el nodo con menor f en la lista abierta
        [~, idx] = min(f(abierta));
        actual = abierta(idx);
        % Si llegamos al nodo objetivo, construimos el camino
        if actual == objetivo
            camino = [];
            while actual ~= 0
                camino = [actual, camino]; %#ok<AGROW>
                actual = predecesor(actual);
            end
            costo_total = g(objetivo);
            return;
        end
        
        % Mover el nodo actual de la lista abierta a la cerrada
        abierta(idx) = [];
        cerrada = [cerrada, actual];

        % Examinar los vecinos del nodo actual
        for vecino = 1:nodos
            if A(actual, vecino) ~= inf && ~ismember(vecino, cerrada)
                tentativo_g = g(actual) + A(actual, vecino);
                if ~ismember(vecino, abierta)
                    abierta = [abierta, vecino];
                end
                if tentativo_g < g(vecino)
                    % Actualizar el costo g y f
                    predecesor(vecino) = actual;
                    g(vecino) = tentativo_g;
                    f(vecino) = g(vecino) + heuristica(vecino, objetivo, coordenadas);
                end
            end
        end
    end
    % Si no se encuentra camino
    camino = [];
    costo_total = inf;
    disp('No se encontró camino');
end

[camino, costo_total] = A_star(A, inicio, objetivo, coordenadas);
disp('Camino encontrado:');
disp(camino);
disp('Costo total:');
disp(costo_total);