% Definir la matriz de adyacencia (grafo)
nodos = 6; % Número de nodos
A = [0 1 4 inf inf inf;
     1 0 2 6 inf inf;
     4 2 0 3 3 inf;
     inf 6 3 0 2 5;
     inf inf 3 2 0 2;
     inf inf inf 5 2 0];
 
% Definir los puntos de los nodos (para la heurística, puede ser una distancia euclidiana)
coordenadas = [0 0;
               1 1;
               2 2;
               3 2;
               4 3;
               5 3];
           
% Definir el nodo de inicio y objetivo
inicio = 1;
objetivo = 6;

% Función heurística (distancia euclidiana a la meta)
function h = heuristica(nodo, objetivo, coordenadas)
    h = norm(coordenadas(nodo,:) - coordenadas(objetivo,:));
end

% Función principal A* con visualización del árbol completo
function [camino, costo_total] = A_star_tree_visual(A, inicio, objetivo, coordenadas)
    % Inicialización
    nodos = size(A, 1);
    g = inf(1, nodos); % Costo desde el inicio a cada nodo
    f = inf(1, nodos); % Costo estimado total (g + h)
    g(inicio) = 0;
    f(inicio) = heuristica(inicio, objetivo, coordenadas);
    abierta = [inicio];
    cerrada = [];
    predecesor = zeros(1, nodos);
    
    % Graficar el mapa del grafo
    fig = figure;
    plot_grafo(A, coordenadas);
    hold on;
    
    % Texto para mostrar la heurística
    heur_text = gobjects(nodos, 1);
    
    % Para trazar el árbol de nodos explorados
    exploracion = [];
    
    while ~isempty(abierta)
        % Encontrar el nodo con menor f en la lista abierta
        [~, idx] = min(f(abierta));
        actual = abierta(idx);
        
        % Si llegamos al nodo objetivo, construimos el camino
        if actual == objetivo
            camino = [];
            while actual ~= 0
                camino = [actual, camino];
                actual = predecesor(actual);
            end
            costo_total = g(objetivo);
            plot_camino(coordenadas, camino); % Dibujar el camino encontrado
            return;
        end
        
        % Mover el nodo actual de la lista abierta a la cerrada
        abierta(idx) = [];
        cerrada = [cerrada, actual];
        
        % Actualizar el gráfico
        plot_nodo(coordenadas, actual, 'r'); % Resaltar el nodo actual
        pause(0.5); % Pausa para animar
        
        % Examinar los vecinos del nodo actual
        for vecino = 1:nodos
            if A(actual, vecino) ~= inf && ~ismember(vecino, cerrada)
                tentativo_g = g(actual) + A(actual, vecino);
                if ~ismember(vecino, abierta)
                    abierta = [abierta, vecino];
                end
                if tentativo_g < g(vecino)
                    % Actualizar el costo g y f
                    predecesor(vecino) = actual;
                    g(vecino) = tentativo_g;
                    f(vecino) = g(vecino) + heuristica(vecino, objetivo, coordenadas);
                    
                    % Actualizar el gráfico para el vecino
                    plot_nodo(coordenadas, vecino, 'g'); % Marcar vecino explorado
                    heur_value = heuristica(vecino, objetivo, coordenadas);
                    delete(heur_text(vecino)); % Borrar texto anterior
                    heur_text(vecino) = text(coordenadas(vecino, 1), coordenadas(vecino, 2), ...
                        sprintf('h=%.2f', heur_value), 'FontSize', 8, 'Color', 'b');
                    
                    % Mostrar la exploración en el árbol
                    exploracion = [exploracion; actual, vecino];
                    plot_arbol(coordenadas, exploracion); % Actualizar árbol de nodos
                    
                    pause(0.5); % Pausa para animar
                end
            end
        end
    end
    
    % Si no se encuentra camino
    camino = [];
    costo_total = inf;
    disp('No se encontró camino');
end

% Función para graficar el grafo
function plot_grafo(A, coordenadas)
    nodos = size(A, 1);
    for i = 1:nodos
        for j = i+1:nodos
            if A(i, j) ~= inf
                plot([coordenadas(i, 1), coordenadas(j, 1)], ...
                     [coordenadas(i, 2), coordenadas(j, 2)], 'k--');
            end
        end
    end
    plot(coordenadas(:, 1), coordenadas(:, 2), 'ko', 'MarkerSize', 10, 'MarkerFaceColor', 'y');
    for i = 1:nodos
        text(coordenadas(i, 1), coordenadas(i, 2), sprintf('%d', i), 'FontSize', 12, 'HorizontalAlignment', 'center');
    end
end

% Función para graficar el nodo
function plot_nodo(coordenadas, nodo, color)
    plot(coordenadas(nodo, 1), coordenadas(nodo, 2), 'o', 'MarkerSize', 10, ...
         'MarkerFaceColor', color, 'MarkerEdgeColor', 'k');
end

% Función para graficar el camino final
function plot_camino(coordenadas, camino)
    for i = 1:length(camino)-1
        plot([coordenadas(camino(i), 1), coordenadas(camino(i+1), 1)], ...
             [coordenadas(camino(i), 2), coordenadas(camino(i+1), 2)], 'r-', 'LineWidth', 2);
    end
end

% Función para graficar el árbol de exploración
function plot_arbol(coordenadas, exploracion)
    for i = 1:size(exploracion, 1)
        nodo1 = exploracion(i, 1);
        nodo2 = exploracion(i, 2);
        plot([coordenadas(nodo1, 1), coordenadas(nodo2, 1)], ...
             [coordenadas(nodo1, 2), coordenadas(nodo2, 2)], 'b-', 'LineWidth', 1.5);
    end
end

% Ejecutar el algoritmo A* con visualización del árbol completo
[camino, costo_total] = A_star_tree_visual(A, inicio, objetivo, coordenadas);
disp('Camino encontrado:');
disp(camino);
disp('Costo total:');
disp(costo_total);
