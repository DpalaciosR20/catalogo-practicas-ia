function createHPLCApp()
    % Crear la figura principal de la aplicación
    fig = uifigure('Name', 'Validación de Método HPLC', 'Position', [100, 100, 800, 400]);

    % Panel de entrada de datos
    panelInputs = uipanel(fig, 'Title', 'Datos de Calibración', 'Position', [20, 150, 260, 200]);
    uilabel(panelInputs, 'Position', [10, 140, 240, 20], 'Text', 'Concentraciones del fármaco (mg/L):');
    inputFarmaco = uitextarea(panelInputs, 'Position', [10, 110, 240, 30], 'Value', {'10', '20', '30', '40', '50'});
    uilabel(panelInputs, 'Position', [10, 80, 240, 20], 'Text', 'Áreas del pico del fármaco:');
    inputAreaFarmaco = uitextarea(panelInputs, 'Position', [10, 50, 240, 30], 'Value', {'1.2', '2.4', '3.6', '4.8', '6.0'});

    % Área de resultados
    panelResultados = uipanel(fig, 'Title', 'Resultados', 'Position', [20, 20, 260, 120]);
    resultadoText = uitextarea(panelResultados, 'Position', [10, 10, 240, 90], ...
        'Editable', 'off', 'Value', {'Resultados aparecerán aquí.'});
    
    % Ejes para las gráficas
    axesFarmaco = uiaxes(fig, 'Position', [300, 100, 220, 260]);
    title(axesFarmaco, 'Curva de Calibración - Fármaco');
    xlabel(axesFarmaco, 'Concentración (mg/L)');
    ylabel(axesFarmaco, 'Área del Pico');
    
    axesImpureza = uiaxes(fig, 'Position', [550, 100, 220, 260]);
    title(axesImpureza, 'Curva de Calibración - Impureza');
    xlabel(axesImpureza, 'Concentración (mg/L)');
    ylabel(axesImpureza, 'Área del Pico');
    
    % Botón para calcular
    calcularBtn = uibutton(fig, 'Position', [300, 50, 100, 30], 'Text', 'Calcular', ...
        'ButtonPushedFcn', @(btn, event) calcularConcentraciones(inputFarmaco, inputAreaFarmaco));

    % Botón de ayuda
    ayudaBtn = uibutton(fig, 'Position', [450, 50, 100, 30], 'Text', 'Ayuda', ...
        'ButtonPushedFcn', @(btn, event) mostrarAyuda());

    % Función para calcular las concentraciones
function calcularConcentraciones(inputFarmaco, inputAreaFarmaco)
    try
        % Datos del fármaco
        concentracion_farmaco = str2double(split(inputFarmaco.Value, ','));
        area_pico_farmaco = str2double(split(inputAreaFarmaco.Value, ','));
        
        % Datos de calibración (pueden ser ajustados)
        concentracion_impureza = [1, 2, 3, 4, 5];
        area_pico_impureza = [0.1, 0.2, 0.3, 0.4, 0.5];
        
        % Calcular las curvas de calibración
        p_farmaco = polyfit(concentracion_farmaco, area_pico_farmaco, 1);
        p_impureza = polyfit(concentracion_impureza, area_pico_impureza, 1);
        
        % Ejemplo de valores medidos (pueden ser personalizados)
        areas_muestras_farmaco = [2, 3];
        areas_muestras_impureza = [0.15, 0.22];
        
        % Calcular concentraciones en las muestras
        conc_muestras_farmaco = (areas_muestras_farmaco - p_farmaco(2)) / p_farmaco(1);
        conc_muestras_impureza = (areas_muestras_impureza - p_impureza(2)) / p_impureza(1);
        
        % Mostrar los resultados
        resultadoText.Value = {
            'Concentraciones del fármaco en las muestras (mg/L):', ...
            sprintf('    %.4f    %.4f', conc_muestras_farmaco), ...
            '', ...
            'Concentraciones de las impurezas en las muestras (mg/L):', ...
            sprintf('    %.4f    %.4f', conc_muestras_impureza)
        };
        
        % Actualizar la gráfica del fármaco
        cla(axesFarmaco);
        plot(axesFarmaco, concentracion_farmaco, area_pico_farmaco, 'o', 'DisplayName', 'Datos');
        hold(axesFarmaco, 'on');
        f_linea_farmaco = polyval(p_farmaco, concentracion_farmaco);
        plot(axesFarmaco, concentracion_farmaco, f_linea_farmaco, 'r-', 'DisplayName', 'Ajuste Lineal');
        legend(axesFarmaco, 'show');
        hold(axesFarmaco, 'off');
        
        % Actualizar la gráfica de impurezas
        cla(axesImpureza);
        plot(axesImpureza, concentracion_impureza, area_pico_impureza, 'o', 'DisplayName', 'Datos');
        hold(axesImpureza, 'on');
        f_linea_impureza = polyval(p_impureza, concentracion_impureza);
        plot(axesImpureza, concentracion_impureza, f_linea_impureza, 'r-', 'DisplayName', 'Ajuste Lineal');
        legend(axesImpureza, 'show');
        hold(axesImpureza, 'off');
    catch
        resultadoText.Value = "Error en los datos ingresados. Verifique las entradas.";
    end
end

    % Función para mostrar la ayuda
    function mostrarAyuda()
        uialert(fig, ['Esta aplicación valida un método de cromatografía HPLC para determinar la pureza de un fármaco. ' ...
                      'Ingrese las concentraciones y áreas de los picos de calibración del fármaco en los campos correspondientes. ' ...
                      'Presione "Calcular" para obtener las curvas de calibración y concentraciones de las muestras.'], ...
                      'Ayuda');
    end
end