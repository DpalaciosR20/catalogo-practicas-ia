% Parámetros del algoritmo genético
numGeneraciones = 100;  % Número de generaciones
poblacionTamano = 50;   % Tamaño de la población
numActivos = 5;         % Número de activos
cruceProb = 0.8;        % Probabilidad de cruce
mutacionProb = 0.1;     % Probabilidad de mutación
lambda = 0.5;           % Peso para balancear retorno y riesgo

% Datos de los activos
retornos = [0.12, 0.18, 0.15, 0.10, 0.08]; % Retornos esperados
covarianza = [0.04, 0.02, 0.01, 0.01, 0.00;  % Matriz de covarianza
              0.02, 0.05, 0.02, 0.01, 0.01;
              0.01, 0.02, 0.03, 0.01, 0.00;
              0.01, 0.01, 0.01, 0.02, 0.01;
              0.00, 0.01, 0.00, 0.01, 0.01];

% Inicialización de la población
poblacion = rand(poblacionTamano, numActivos);
poblacion = poblacion ./ sum(poblacion, 2); % Normalizar para que las proporciones sumen 1

% Función de fitness
fitness_func = @(p) sum(p .* retornos) - lambda * (p * covarianza * p');

for generacion = 1:numGeneraciones
    % Evaluar fitness
    fitness = arrayfun(@(i) fitness_func(poblacion(i, :)), 1:poblacionTamano);

    % Selección: torneo
    nuevaPoblacion = zeros(size(poblacion));
    for i = 1:poblacionTamano
        ind1 = randi(poblacionTamano);
        ind2 = randi(poblacionTamano);
        if fitness(ind1) > fitness(ind2)
            nuevaPoblacion(i, :) = poblacion(ind1, :);
        else
            nuevaPoblacion(i, :) = poblacion(ind2, :);
        end
    end

    % Cruce
    for i = 1:2:poblacionTamano-1
        if rand < cruceProb
            puntoCruce = randi(numActivos-1);
            padre1 = nuevaPoblacion(i, :);
            padre2 = nuevaPoblacion(i+1, :);
            nuevaPoblacion(i, :) = [padre1(1:puntoCruce), padre2(puntoCruce+1:end)];
            nuevaPoblacion(i+1, :) = [padre2(1:puntoCruce), padre1(puntoCruce+1:end)];
        end
    end

    % Mutación
    for i = 1:poblacionTamano
        if rand < mutacionProb
            mutacionIdx = randi(numActivos);
            nuevaPoblacion(i, mutacionIdx) = rand;
            nuevaPoblacion(i, :) = nuevaPoblacion(i, :) / sum(nuevaPoblacion(i, :));
        end
    end

    % Actualizar población
    poblacion = nuevaPoblacion;

    % Mostrar el mejor fitness
    disp(['Generación ', num2str(generacion), ': Mejor fitness = ', num2str(max(fitness))]);
end

% Resultados finales
[~, mejorIdx] = max(fitness);
mejorSolucion = poblacion(mejorIdx, :);
disp('Mejor portafolio encontrado:');
disp(mejorSolucion);
