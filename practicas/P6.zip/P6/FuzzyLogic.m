% Crear un sistema difuso
sistema_fuzzy = mamfis('Name','Control Ventilador');

% Agregar la entrada de temperatura con funciones de pertenencia
sistema_fuzzy = addInput(sistema_fuzzy, [0 100], 'Name', 'Temperatura');
sistema_fuzzy = addMF(sistema_fuzzy, 'Temperatura', 'gaussmf', [10 0], 'Name',...
'Baja');
sistema_fuzzy = addMF(sistema_fuzzy, 'Temperatura', 'gaussmf', [10 50],...
'Name', 'Media');
sistema_fuzzy = addMF(sistema_fuzzy, 'Temperatura', 'gaussmf', [10 100],...
'Name', 'Alta');

% Agregar la salida de velocidad del ventilador con funciones de pertenencia
sistema_fuzzy = addOutput(sistema_fuzzy, [0 10], 'Name', 'Velocidad');
sistema_fuzzy = addMF(sistema_fuzzy, 'Velocidad', 'trimf', [0 0 5], 'Name',...
'Lenta');
sistema_fuzzy = addMF(sistema_fuzzy, 'Velocidad', 'trimf', [0 5 10], 'Name',...
'Media');
sistema_fuzzy = addMF(sistema_fuzzy, 'Velocidad', 'trimf', [5 10 10], 'Name',...
'Rapida');

% Definir las reglas
reglas = [
"If Temperatura is Baja then Velocidad is Lenta"
"If Temperatura is Media then Velocidad is Media"
"If Temperatura is Alta then Velocidad is Rapida"
];
sistema_fuzzy = addRule(sistema_fuzzy, reglas);

% Evaluar el sistema difuso
entrada = 100; % Temperatura de entrada
salida = evalfis(sistema_fuzzy, entrada);

disp(['Entrada: ', num2str(entrada)]);
disp(['La velocidad del ventilador es: ', num2str(salida)]);