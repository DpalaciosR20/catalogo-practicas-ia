% Crear el sistema difuso
control_ventilador = mamfis('Name','Control Ventilador');

% Agregar la entrada de temperatura (0 a 40 grados)
control_ventilador = addInput(control_ventilador, [0 40], 'Name','Temperatura');

% Definir funciones de pertenencia para la temperatura
control_ventilador = addMF(control_ventilador, 'Temperatura', 'trimf', [0 0 15], ...
    'Name', 'Baja');
control_ventilador = addMF(control_ventilador, 'Temperatura', 'trimf', [10 20 30],...
    'Name', 'Media');
control_ventilador = addMF(control_ventilador, 'Temperatura', 'trimf', [25 40 40],...
    'Name', 'Alta');

% Agregar la salida de velocidad del ventilador (0 a 10)
control_ventilador = addOutput(control_ventilador, [0 10], 'Name', 'Velocidad');

% Definir funciones de pertenencia para la velocidad del ventilador
control_ventilador = addMF(control_ventilador, 'Velocidad', 'trimf', [0 0 5],...
    'Name', 'Lenta');
control_ventilador = addMF(control_ventilador, 'Velocidad', 'trimf', [2.5 5 7.5],...
    'Name', 'Media');
control_ventilador = addMF(control_ventilador, 'Velocidad', 'trimf', [5 10 10],...
    'Name', 'Rapida');

% Definir las reglas del sistema difuso
reglas = [
"If Temperatura is Baja then Velocidad is Lenta"
"If Temperatura is Media then Velocidad is Media"
"If Temperatura is Alta then Velocidad is Rapida"
];
control_ventilador = addRule(control_ventilador, reglas);

% Visualizar el sistema difuso
figure
plotfis(control_ventilador)

% Evaluar el sistema difuso con diferentes temperaturas
temperaturas = [5, 15, 25, 35]; % Ejemplos de entradas de temperatura
for i = 1:length(temperaturas)
    temp = temperaturas(i);
    velocidad = evalfis(control_ventilador, temp);
    fprintf('Para una temperatura de %.1f°C, la velocidad del ventilador es %.2f\n', temp, velocidad);
end

% Visualizar las funciones de pertenencia
figure
subplot(2,1,1)
plotmf(control_ventilador, 'input', 1)
title('Funciones de pertenencia de la Temperatura')
subplot(2,1,2)
plotmf(control_ventilador, 'output', 1)
title('Funciones de pertenencia de la Velocidad')