% Generar datos sintéticos
rng(1); % Reproducibilidad
numCasas = 500;
tamano = rand(numCasas, 1) * 200 + 50; % tamano en m² (50 a 250 m²)
habitaciones = randi([1, 5], numCasas, 1); % Número de habitaciones (1 a 5)
banos = randi([1, 3], numCasas, 1); % Número de banos (1 a 3)
ubicacion = randi([1, 3], numCasas, 1); % Zonas codificadas (1 a 3)

% Generar precios con ruido
precios = 50000 + 300 * tamano + 20000 * habitaciones + ...
          15000 * banos + 10000 * ubicacion + randn(numCasas, 1) * 10000;

% Crear matriz de características
X = [tamano, habitaciones, banos, ubicacion];
Y = precios;

% Dividir en conjunto de entrenamiento y prueba
cv = cvpartition(numCasas, 'HoldOut', 0.3); % 30% para prueba
idx = cv.test;

XTrain = X(~idx, :);
YTrain = Y(~idx, :);
XTest = X(idx, :);
YTest = Y(idx, :);

% Normalizar características
[XTrain, mu, sigma] = zscore(XTrain); % Media y desviación estándar
XTest = (XTest - mu) ./ sigma; % Normalizar conjunto de prueba

% Crear la red neuronal
net = fitrnet(XTrain, YTrain, ...
              'LayerSizes', [20, 10], ... % Dos capas ocultas con 20 y 10 neuronas
              'Activations', 'relu', ... % Función de activación ReLU
              'Standardize', true); % Estandarizar las características

% Predecir en el conjunto de prueba
YPred = predict(net, XTest);

% Evaluar el modelo
mse = mean((YPred - YTest).^2);
fprintf('Error cuadrático medio (MSE): %.2f\n', mse);

% Visualizar resultados
figure;
scatter(YTest, YPred, 'filled');
hold on;
plot([min(YTest), max(YTest)], [min(YTest), max(YTest)], 'r--');
title('Predicción de precios de casas');
xlabel('Precios reales');
ylabel('Precios predichos');
grid on;
legend('Predicciones', 'Línea ideal');
hold off;
