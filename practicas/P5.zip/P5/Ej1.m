%% Verificación de cuántos individuos cumplen una propiedad %%

% Definir un conjunto de individuos
X = [1, 2, 3, 4, 5, 6];
% Definir el predicado P(x): 'x es un número par'
P = @(x) mod(x, 2) == 0;
% Cuantificador universal: verificar si todos los elementos cumplen P(x)
todos_cumplen = all(arrayfun(P, X));
% Cuantificador existencial: verificar si existe al menos un elemento que cumple P(x)
existe_al_menos_uno = any(arrayfun(P, X));
fprintf('Todos cumplen P(x): %d\n', todos_cumplen);
fprintf('Existe al menos uno que cumple P(x): %d\n', existe_al_menos_uno);