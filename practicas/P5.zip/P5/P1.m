% Datos de las fuentes de agua: [pH, nitratos (mg/L)]
fuentes = [
            7.2, 30; % Fuente 1: pH = 7.2, nitratos = 30 mg/L
            8.0, 45; % Fuente 2: pH = 8.0, nitratos = 45 mg/L
            6.3, 40; % Fuente 3: pH = 6.3, nitratos = 40 mg/L (pH fuera de rango)
            7.8, 55; % Fuente 4: pH = 7.8, nitratos = 55 mg/L (nitratos fuera de rango)
            6.9, 20 % Fuente 5: pH = 6.9, nitratos = 20 mg/L
        ];
% Definir el predicado P(x): pH entre 6.5 y 8.5
P = @(ph) (ph >= 6.5) & (ph <= 8.5);

% Definir el predicado Q(x): nitratos < 50 mg/L
Q = @(nitratos) nitratos < 50;

% Verificar si cada fuente cumple los estándares
S = @(ph, nitratos) P(ph) & Q(nitratos);

% Aplicar la función a todas las fuentes
cumplimiento = arrayfun(@(i) S(fuentes(i, 1), fuentes(i, 2)), 1:size(fuentes,1));

% Verificar si todas las fuentes cumplen con los estándares
todas_cumplen = all(cumplimiento);
existe_al_menos_una_no_cumple = any(~cumplimiento);

% Resultados
if todas_cumplen
    fprintf('Todas las fuentes de agua cumplen con los estándares de calidad.\n');
else
    fprintf('Al menos una fuente de agua no cumple con los estándares de calidad.\n');
    fprintf('Fuentes que no cumplen:\n');
    disp(find(~cumplimiento)); % Muestra el índice de las fuentes que no cumplen
end