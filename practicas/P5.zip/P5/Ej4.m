%% Cuantificadores en dominios más complejos %%

% Definir un conjunto de pares de números
X = [1 2; 3 1; 5 6; 4 4];
% Definir el predicado P(x, y): 'x > y'
P = @(x, y) x > y;
% Cuantificador existencial: verificar si existe un par que cumple P(x, y)
existe_al_menos_un_par = any(arrayfun(@(i) P(X(i, 1), X(i, 2)), 1:size(X, 1)));
fprintf('Existe al menos un par que cumple P(x, y): %d\n', ...
existe_al_menos_un_par);