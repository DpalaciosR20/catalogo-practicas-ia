%% Lógica cuantificacional con programación simbólica %%

% Usar el toolbox simbólico de MATLAB
syms x
% Definir un predicado simbólico
P = (mod(x, 2) == 0); % P(x): 'x es par'
Q = (x > 1); % Q(x): 'x es mayor que 1'
% Verificar la implicación P(x) -> Q(x) simbólicamente
implicacion = simplify(~P | Q);
disp(implicacion);