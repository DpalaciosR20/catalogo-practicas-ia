%% Verificar si una regla lógica es válida en un dominio %%

% Definir el conjunto de individuos
X = [0, 1, 2, 3, 4, 5];
% Definir los predicados
P = @(x) mod(x, 2) == 0; % P(x): 'x es par'
Q = @(x) x > 1; % Q(x): 'x es mayor que 1'
% Cuantificador universal para la implicación P(x) -> Q(x)
todos_cumplen_implicacion = all(arrayfun(@(x) ~P(x) || Q(x), X));
fprintf('Todos los elementos cumplen P(x) -> Q(x): %d\n', ... 
todos_cumplen_implicacion);