% Generar datos sintéticos para pacientes
rng(1); % Para reproducibilidad
numSamples = 200; % Número total de pacientes

% Características:
% 1. Edad (años)
% 2. Presión arterial sistólica (mmHg)
% 3. Nivel de colesterol (mg/dL)

% Generar datos para pacientes de bajo riesgo
X_lowRisk = [randi([20, 40], numSamples/2, 1), ...  % Edad joven
             randi([90, 120], numSamples/2, 1), ... % Baja presión arterial
             randi([150, 200], numSamples/2, 1)];  % Nivel de colesterol normal

% Generar datos para pacientes de alto riesgo
X_highRisk = [randi([50, 80], numSamples/2, 1), ...  % Edad avanzada
              randi([130, 180], numSamples/2, 1), ... % Alta presión arterial
              randi([220, 300], numSamples/2, 1)];   % Alto colesterol

% Combinar datos
X = [X_lowRisk; X_highRisk];
Y = [repmat("Bajo Riesgo", numSamples/2, 1); repmat("Alto Riesgo", numSamples/2, 1)];

% Entrenar el árbol de decisión
tree = fitctree(X, Y);

% Crear la interfaz gráfica
f = figure('Name', 'Clasificación de Riesgo Cardíaco', 'Position', [100, 100, 600, 400]);

% Ejes para visualización de datos
ax = axes('Parent', f, 'Position', [0.1, 0.3, 0.8, 0.6]);
gscatter(X(:, 1), X(:, 2), Y, 'br', 'xo');
xlabel(ax, 'Edad');
ylabel(ax, 'Presión Arterial Sistólica');
title(ax, 'Datos Sintéticos de Pacientes');
legend(ax, 'Bajo Riesgo', 'Alto Riesgo');

% Botón de predicción
uicontrol('Style', 'text', 'Parent', f, 'Position', [50, 100, 100, 30], 'String', 'Edad:');
inputEdad = uicontrol('Style', 'edit', 'Parent', f, 'Position', [150, 100, 100, 30]);

uicontrol('Style', 'text', 'Parent', f, 'Position', [50, 60, 100, 30], 'String', 'Presión:');
inputPresion = uicontrol('Style', 'edit', 'Parent', f, 'Position', [150, 60, 100, 30]);

uicontrol('Style', 'text', 'Parent', f, 'Position', [50, 20, 100, 30], 'String', 'Colesterol:');
inputColesterol = uicontrol('Style', 'edit', 'Parent', f, 'Position', [150, 20, 100, 30]);

btnPredict = uicontrol('Style', 'pushbutton', 'Parent', f, 'Position', [300, 60, 100, 40], 'String', 'Predecir', ...
    'Callback', @(~, ~) predictRisk(inputEdad, inputPresion, inputColesterol, tree));

% Botón de ayuda
btnHelp = uicontrol('Style', 'pushbutton', 'Parent', f, 'Position', [450, 60, 100, 40], 'String', 'Ayuda', ...
    'Callback', @(~, ~) showHelp());

% Función para predecir el riesgo
function predictRisk(inputEdad, inputPresion, inputColesterol, tree)
    edad = str2double(get(inputEdad, 'String'));
    presion = str2double(get(inputPresion, 'String'));
    colesterol = str2double(get(inputColesterol, 'String'));
    if isnan(edad) || isnan(presion) || isnan(colesterol)
        msgbox('Por favor, ingrese valores válidos.', 'Error', 'error');
        return;
    end
    newPatient = [edad, presion, colesterol];
    predictedLabel = predict(tree, newPatient);
    msgbox(['El paciente es clasificado como: ', char(predictedLabel)], 'Resultado');
end

% Función para mostrar ayuda
function showHelp()
    helpText = ['Este programa utiliza un árbol de decisión para clasificar pacientes ', ...
                'en "Bajo Riesgo" o "Alto Riesgo" de desarrollar una enfermedad cardíaca.\n', ...
                'El algoritmo analiza características como la edad, presión arterial sistólica ', ...
                'y nivel de colesterol para realizar la clasificación.\n', ...
                'El árbol de decisión se entrena con datos sintéticos que simulan diferentes casos.'];
    msgbox(helpText, 'Ayuda');
end