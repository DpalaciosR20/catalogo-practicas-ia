%% Programa para evaluar la eficiencia de un sensor infrarrojo

% Definir las variables
sensor = ["S1", "S2", "S3", "S4", "S5"];
entrada_prueba = [
    0,0,0,0,0; % Prueba 1
    1,1,1,1,1; % Prueba 2
    0,0,0,0,0; % Prueba 3
    1,1,1,1,1; % Prueba 4
    0,0,0,0,0; % Prueba 5
    1,1,1,1,1; % Prueba 6
    0,0,0,0,0; % Prueba 7
    1,1,1,1,1; % Prueba 8
    0,0,0,0,0; % Prueba 9
    1,1,1,1,1  % Prueba 10
];
salida_prueba = [
    0,0,0,0,1; % Prueba 1
    0,1,1,1,0; % Prueba 2
    0,0,0,0,0; % Prueba 3
    1,1,0,1,1; % Prueba 4
    0,0,0,0,0; % Prueba 5
    1,1,0,1,1; % Prueba 6
    1,0,0,1,1; % Prueba 7
    1,1,0,1,1; % Prueba 8
    0,0,0,0,1; % Prueba 9
    1,1,1,1,1  % Prueba 10
];

% Calcular detecciones correctas y eficiencia por sensor
detecciones_correctas = sum(entrada_prueba == salida_prueba, 1);
total_pruebas = size(entrada_prueba, 1);
eficiencia = (detecciones_correctas / total_pruebas) * 100;

% Crear la tabla de datos
datosSensores = table(sensor', detecciones_correctas', eficiencia', ...
    'VariableNames', {'Sensor', 'Detecciones_Correctas', 'Eficiencia'});

% Crear una aplicación básica con MATLAB App Designer
definirGUI();

function definirGUI()
    % Crear la figura principal
    fig = uifigure('Name', 'Eficiencia de Sensor Infrarrojo', 'Position', [100, 100, 600, 300]);

    % Crear tabla para mostrar los datos
    uitable(fig, 'Data', evalin('base', 'datosSensores'), ...
        'Position', [20, 120, 560, 145]);

    % Campo de texto para mostrar eficiencia promedio
    uilabel(fig, 'Position', [20, 20, 200, 22], 'Text', 'Eficiencia Promedio:');
    eficienciaLabel = uilabel(fig, 'Position', [150, 20, 100, 22], 'Text', '');

    % Botón para calcular eficiencia promedio
    calcularBtn = uibutton(fig, 'Text', 'Calcular Promedio', 'Position', [20, 50, 150, 22], ...
        'ButtonPushedFcn', @(btn, event) calcularPromedio(eficienciaLabel));

    % Botón de ayuda
    ayudaBtn = uibutton(fig, 'Text', '?', 'Position', [550, 20, 20, 20], ...
        'FontWeight', 'bold',...
        'ButtonPushedFcn', @(btn, event) mostrarAyuda());
end

function calcularPromedio(label)
    datos = evalin('base', 'datosSensores');
    promedio = mean(datos.Eficiencia);
    label.Text = sprintf('%.2f%%', promedio);
end

function mostrarAyuda()
    % Crear ventana de ayuda
    ayudaFig = uifigure('Name', 'Ayuda', 'Position', [150, 150, 650, 250]);

    % Texto detallado de ayuda
    msg = [
        "Este programa evalúa la eficiencia de sensores infrarrojos."
        ""
        "Funcionamiento:"
        "1. Los datos de entrada y salida se definen para simular pruebas realizadas a los sensores."
        "2. La eficiencia se calcula como el porcentaje de detecciones correctas realizadas por cada sensor."
        "3. Los resultados se presentan en una tabla que muestra las detecciones correctas y la eficiencia por sensor."
        ""
        "Estructura de las tablas:"
        "- La tabla contiene las columnas:"
        "    * Sensor: Identificador del sensor (S1, S2, ...)."
        "    * Detecciones_Correctas: Número de pruebas donde la salida coincidió con la entrada esperada."
        "    * Eficiencia: Porcentaje de aciertos calculado como (detecciones correctas / total de pruebas) * 100."
    ];

    uilabel(ayudaFig, 'Text', strjoin(msg, '\n'), 'Position', [20, 50, 650, 180], ...
        'HorizontalAlignment', 'left', 'VerticalAlignment', 'top');
end