% Definimos el grafo como una matriz de adyacencia
% Ejemplo de grafo:
% Nodo 1 está conectado a 2 y 3
% Nodo 2 está conectado a 4
% Nodo 3 está conectado a 4 y 5
% Nodo 4 está conectado a 6
% Nodo 5 está conectado a 6
% Nodo 6 no tiene más conexiones
adjMatrix = [0 1 1 0 0 0; % Nodo 1
            0 0 0 1 0 0; % Nodo 2
            0 0 0 1 1 0; % Nodo 3
            0 0 0 0 0 1; % Nodo 4
            0 0 0 0 0 1; % Nodo 5
            0 0 0 0 0 0]; % Nodo 6

function dfs(adjMatrix, currentNode, visited)
    % Número de nodos en el grafo
    numNodes = size(adjMatrix, 1);
    % Marcar el nodo actual como visitado
    visited(currentNode) = true;
    % Mostrar el nodo actual
    fprintf('Visitando nodo %d\n', currentNode);
    % Recorrer los vecinos no visitados del nodo actual
    for neighbor = 1:numNodes
        if adjMatrix(currentNode, neighbor) == 1 && ~visited(neighbor)
            % Si el vecino no ha sido visitado, hacer la llamada recursiva
            dfs(adjMatrix, neighbor, visited);
        end
    end
end

% Definir el nodo de inicio
startNode = 1;
% Inicializar el vector de nodos visitados
visited = false(1, size(adjMatrix, 1));
% Llamar a la función de búsqueda en profundidad
dfs(adjMatrix, startNode, visited);