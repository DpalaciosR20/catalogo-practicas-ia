function bfs_with_visualization(adjMatrix, startNode)
    % Crear la figura principal
    figure;
    hold on;
    axis off;
    title('Visualización del Árbol BFS');
    
    % Definir posiciones fijas para los nodos
    nodePositions = [
        1, 0.2;  % Nodo 1
        0, 0;  % Nodo 2
        2, 0;  % Nodo 3
        0, -0.2;  % Nodo 4
        2, -0.2;  % Nodo 5
        1, -0.4;  % Nodo 6
    ];

    % Dibujar los nodos
    numNodes = size(adjMatrix, 1);
    for i = 1:numNodes
        plot(nodePositions(i,1), nodePositions(i,2), 'ko', 'MarkerSize', 10, 'MarkerFaceColor', 'w');
        text(nodePositions(i,1), nodePositions(i,2)+.05, sprintf('Nodo %d', i), 'HorizontalAlignment', 'center');
    end
    
    % Crear botón para mostrar explicación del algoritmo
    uicontrol('Style', 'pushbutton', 'String', 'Explicación del Algoritmo', ...
              'Position', [20 20 200 40], 'Callback', @showExplanation);
    
    % Inicializar el texto de la explicación
    explanationText = annotation('textbox', [0.7, 0.8, 0.3, 0.1], 'String', '', 'EdgeColor', 'none', 'FontSize', 12);
    
    % BFS
    queue = [startNode];
    visited = false(1, numNodes);
    visited(startNode) = true;
    
    while ~isempty(queue)
        currentNode = queue(1);
        queue(1) = [];
        
        % Actualizar el texto de la explicación
        explanation = sprintf('Visitando nodo %d\n', currentNode);
        set(explanationText, 'String', explanation);
        pause(1);  % Pausa para que sea visible
        
        % Actualizar el nodo visitado
        plot(nodePositions(currentNode, 1), nodePositions(currentNode, 2), 'ko', 'MarkerSize', 10, 'MarkerFaceColor', 'g');
        
        % Revisar los vecinos
        for neighbor = 1:numNodes
            if adjMatrix(currentNode, neighbor) == 1 && ~visited(neighbor)
                queue = [queue, neighbor];
                visited(neighbor) = true;
                
                % Dibujar la conexión entre nodos
                plot([nodePositions(currentNode, 1), nodePositions(neighbor, 1)], ...
                     [nodePositions(currentNode, 2), nodePositions(neighbor, 2)], 'k-');
                 
                % Actualizar la explicación
                explanation = sprintf('Nodo %d conectado con nodo %d\n', currentNode, neighbor);
                set(explanationText, 'String', explanation);
                pause(1);  % Pausa para visualizar la conexión
            end
        end
    end

    % Explicación final
    set(explanationText, 'String', 'BFS completado.');
end

% Función para mostrar la ventana emergente con la explicación
function showExplanation(~, ~)
    msgbox({
            'La búsqueda en anchura explora el espacio de búsqueda nivel por nivel,', ...
            'comenzando desde el nodo raíz y expandiendo todos sus vecinos antes de proceder a los nodos', ...
            'en niveles más profundos. Es un algoritmo que garantiza encontrar la solución óptima si todas', ...
            'las transiciones tienen el mismo costo.', '',...
            'Funcionamiento:', ...
            '1. Coloca el nodo inicial en una cola (FIFO).', ...
            '2. Extrae el primer nodo de la cola, lo expande y añade sus vecinos (nodos hijos) al final de la cola.', ...
            '3. Repite el proceso hasta que encuentra el nodo objetivo o se hayan explorado todos los nodos.', '',...
            'Complejidad temporal: O(b^d), donde:', ...
            '1. b es el factor de ramificación (número promedio de hijos por nodo).', ...
            '2. d es la profundidad de la solución más cercana.', '',...
            'Complejidad espacial: O(b^d), ya que se deben mantener en memoria todos los nodos del nivel actual.'}, ...
            'Explicación del Algoritmo BFS');
end


% Definir el grafo
adjMatrix = [0 1 1 0 0 0;
             0 0 0 1 0 0;
             0 0 0 1 1 0;
             0 0 0 0 0 1;
             0 0 0 0 0 1;
             0 0 0 0 0 0];

% Ejecutar la visualización BFS
startNode = 1;
bfs_with_visualization(adjMatrix, startNode);
