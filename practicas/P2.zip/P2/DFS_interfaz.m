function dfs_with_visualization(adjMatrix, currentNode, visited, nodePositions)
    % Crear la figura principal
    figure;
    hold on;
    axis off;
    title('Visualización del Árbol DFS');
    
    % Dibujar los nodos
    numNodes = size(adjMatrix, 1);
    for i = 1:numNodes
        plot(nodePositions(i,1), nodePositions(i,2), 'ko', 'MarkerSize', 10, 'MarkerFaceColor', 'w');
        text(nodePositions(i,1), nodePositions(i,2)+.05, sprintf('Nodo %d', i), 'HorizontalAlignment', 'center');
    end
    
    % Crear botón para mostrar explicación del algoritmo
    uicontrol('Style', 'pushbutton', 'String', 'Explicación del Algoritmo', ...
              'Position', [20 20 200 40], 'Callback', @showExplanation);
    
    % Inicializar el texto de la explicación
    explanationText = annotation('textbox', [0.7, 0.8, 0.3, 0.1], 'String', '', 'EdgeColor', 'none', 'FontSize', 12);
    
    % Llamar a la función DFS recursiva
    dfs_recursive(adjMatrix, currentNode, visited, nodePositions, explanationText);
    
    % Explicación final
    set(explanationText, 'String', 'DFS completado.');
end

% Función DFS recursiva
function dfs_recursive(adjMatrix, currentNode, visited, nodePositions, explanationText)
    % Marcar el nodo actual como visitado
    visited(currentNode) = true;
    
    % Actualizar el texto de la explicación
    explanation = sprintf('Visitando nodo %d\n', currentNode);
    set(explanationText, 'String', explanation);
    pause(1);  % Pausa para que sea visible
    
    % Actualizar el nodo visitado
    plot(nodePositions(currentNode, 1), nodePositions(currentNode, 2), 'ko', 'MarkerSize', 10, 'MarkerFaceColor', 'g');
    
    % Revisar los vecinos no visitados del nodo actual
    numNodes = size(adjMatrix, 1);
    for neighbor = 1:numNodes
        if adjMatrix(currentNode, neighbor) == 1 && ~visited(neighbor)
            % Dibujar la conexión entre nodos con grosor ajustado
            plot([nodePositions(currentNode, 1), nodePositions(neighbor, 1)], ...
                 [nodePositions(currentNode, 2), nodePositions(neighbor, 2)], 'k-', 'LineWidth', 1);
             
            % Actualizar la explicación
            explanation = sprintf('Nodo %d conectado con nodo %d\n', currentNode, neighbor);
            set(explanationText, 'String', explanation);
            pause(1);  % Pausa para visualizar la conexión
            
            % Hacer la llamada recursiva
            dfs_recursive(adjMatrix, neighbor, visited, nodePositions, explanationText);
        end
    end
end

% Función para mostrar la ventana emergente con la explicación
function showExplanation(~, ~)
    msgbox({'La búsqueda en profundidad explora un camino completo desde el nodo inicial hasta', ...
            'un nodo hoja antes de retroceder y probar otros caminos. Sigue el camino más profundo posible', ...
            'antes de retroceder.', '',...
            'Funcionamiento:', ...
            '1. Se coloca el nodo inicial en una pila (LIFO).', ...
            '2. Extrae el nodo de la cima de la pila, lo expande y coloca sus vecinos en la pila.', ...
            '3. Repite hasta encontrar el nodo objetivo o hasta que se hayan visitado todos los nodos posibles.', '',...
            'Complejidad temporal: O(b^d) (similar a BFS).', '',...
            'Complejidad espacial: O(b*d), ya que solo necesita almacenar la rama actual del árbol y algunos', ...
            'nodos auxiliares.'}, ...
            'Explicación del Algoritmo DFS');
end


% Definir el grafo como una matriz de adyacencia
adjMatrix = [0 1 1 0 0 0; % Nodo 1
             0 0 0 1 0 0; % Nodo 2
             0 0 0 1 1 0; % Nodo 3
             0 0 0 0 0 1; % Nodo 4
             0 0 0 0 0 1; % Nodo 5
             0 0 0 0 0 0]; % Nodo 6

% Definir posiciones de los nodos
nodePositions = [
    1, 0.2;  % Nodo 1
    0, 0;  % Nodo 2
    2, 0;  % Nodo 3
    0, -0.2;  % Nodo 4
    2, -0.2;  % Nodo 5
    1, -0.4;  % Nodo 6
];

% Definir el nodo de inicio
startNode = 1;
% Inicializar el vector de nodos visitados
visited = false(1, size(adjMatrix, 1));
% Ejecutar la visualización DFS
dfs_with_visualization(adjMatrix, startNode, visited, nodePositions);
