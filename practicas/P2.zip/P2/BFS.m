% Definimos el grafo como una matriz de adyacencia
% Ejemplo de grafo:
% Nodo 1 está conectado a 2 y 3
% Nodo 2 está conectado a 4
% Nodo 3 está conectado a 4 y 5
% Nodo 4 está conectado a 6
% Nodo 5 está conectado a 6
% Nodo 6 no tiene más conexiones
adjMatrix = [0 1 1 0 0 0; % Nodo 1
            0 0 0 1 0 0; % Nodo 2
            0 0 0 1 1 0; % Nodo 3
            0 0 0 0 0 1; % Nodo 4
            0 0 0 0 0 1; % Nodo 5
            0 0 0 0 0 0]; % Nodo 6

function bfs(adjMatrix, startNode)
    % Número de nodos en el grafo
    numNodes = size(adjMatrix, 1);
    % Inicializar una cola para nodos por visitar
    queue = [startNode];
    % Vector para marcar los nodos visitados
    visited = false(1, numNodes);
    
    % Marcar el nodo inicial como visitado
    visited(startNode) = true;
    % Iterar mientras haya nodos en la cola
    while ~isempty(queue)
        % Extraer el primer nodo de la cola
        currentNode = queue(1);
        queue(1) = [];
        % Mostrar el nodo actual
        fprintf('Visitando nodo %d\n', currentNode);
        % Revisar los nodos adyacentes
        for neighbor = 1:numNodes
            if adjMatrix(currentNode, neighbor) == 1 && ~visited(neighbor)
                % Si hay una conexión y el nodo no ha sido visitado, agregarlo a la cola
                queue = [queue, neighbor];
                % Marcar el vecino como visitado
                visited(neighbor) = true;
            end
        end
    end
end

startNode = 1;
bfs(adjMatrix, startNode);