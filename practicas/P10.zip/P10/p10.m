% Cargar el conjunto de datos MNIST reducido
load('mnist_reducido.mat'); 
% X: matriz de imágenes (n muestras x m características)
% Y: vector de etiquetas correspondientes (n x 1)

% Preprocesamiento de datos
X = double(X) / 255; % Normalizar los valores de píxeles a [0,1]

% Separar datos en entrenamiento (70%) y prueba (30%)
cv = cvpartition(Y, 'HoldOut', 0.3);
Xtrain = X(training(cv), :);
Ytrain = Y(training(cv), :);
Xtest = X(test(cv), :);
Ytest = Y(test(cv), :);

% Entrenar el clasificador K-Vecinos Más Cercanos (K-NN)
k = 5; % Número de vecinos
mdl = fitcknn(Xtrain, Ytrain, 'NumNeighbors', k, 'Distance', 'euclidean');

% Realizar predicciones en el conjunto de prueba
Ypred = predict(mdl, Xtest);

% Evaluar el rendimiento del clasificador
accuracy = sum(Ypred == Ytest) / length(Ytest) * 100;
fprintf('Precisión del clasificador K-NN: %.2f%%\n', accuracy);

% Mostrar la matriz de confusión
figure;
confusionchart(Ytest, Ypred);
title('Matriz de Confusión del Clasificador K-NN');

% Visualizar algunas predicciones
numExamples = 5;
figure;
for i = 1:numExamples
    subplot(1, numExamples, i);
    imshow(reshape(Xtest(i, :), [28, 28]), []); % Ajusta si el tamaño es diferente
    title(sprintf('Etiqueta: %d\nPredicción: %d', Ytest(i), Ypred(i)));
end
