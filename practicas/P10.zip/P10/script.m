% Descargar el conjunto de datos MNIST
[trainImages, trainLabels] = digitTrain4DArrayData; % Imágenes y etiquetas

% Verificar etiquetas originales
disp('Etiquetas originales en el conjunto MNIST:');
disp(unique(trainLabels)); % Verifica que las etiquetas estén en el rango [0, 9]

% Reducir el tamaño del conjunto
numSamples = 1000; % Número de imágenes a usar
X = reshape(trainImages(:, :, 1, 1:numSamples), [], numSamples)'; % Aplanar imágenes

% Ajustar las etiquetas para que estén en el rango [0, 9]
Y = double(trainLabels(1:numSamples)) - 1; % Restar 1 para corregir las etiquetas (si es necesario)

% Verificar etiquetas del conjunto reducido
disp('Etiquetas en el conjunto reducido:');
disp(unique(Y)); % Verificar que las etiquetas estén dentro del rango [0, 9]

% Guardar el conjunto reducido en un archivo .mat
save('mnist_reducido.mat', 'X', 'Y');