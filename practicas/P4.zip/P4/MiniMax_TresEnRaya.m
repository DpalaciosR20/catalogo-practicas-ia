% Minimax algorithm for Tic-Tac-Toe (Tres en Raya)
function bestMove = minimax_example()
    % Inicializa el tablero (0 = vacío, 1 = X, -1 = O)
    board = [0 0 0; 0 0 0; 0 0 0];
    
    % Llama a la función minimax para encontrar el mejor movimiento
    [~, bestMove] = minimax(board, 1);
end

% Función Minimax
% board: el estado actual del tablero
% player: 1 (MAX, jugador X) o -1 (MIN, jugador O)
function [score, move] = minimax(board, player)
    % Revisa si hay un ganador o si es empate
    winner = check_winner(board);
    
    if winner ~= 0
        % Retorna la evaluación: 1 si X gana, -1 si O gana, 0 si es empate
        score = winner;
        move = [];
        return;
    elseif isempty(find(board == 0, 1))
        % Si no quedan movimientos posibles, es empate
        score = 0;
        move = [];
        return;
    end

    % Inicialización
    bestScore = -inf * ,;
    bestMove = [];

    % Bucle para probar cada posible movimiento
    for i = 1:3
        for j = 1:3
            if board(i, j) == 0
                % Simula el movimiento
                board(i, j) = player;
                
                % Evalúa el tablero después de ese movimiento
                [nextScore, ~] = minimax(board, -player);
                
                % Deshace el movimiento
                board(i, j) = 0;
                
                % Actualiza el mejor movimiento
                if (player == 1 && nextScore > bestScore) || (player == -1 && ...
                    nextScore < bestScore)
                    bestScore = nextScore;
                    bestMove = [i, j];
                end
            end
        end
    end

    % Retorna la mejor puntuación y el mejor movimiento
    score = bestScore;
    move = bestMove;
end

% Función para revisar si hay un ganador
function winner = check_winner(board)
    % Comprobación de filas, columnas y diagonales
    for i = 1:3
        if abs(sum(board(i, :))) == 3 % Revisa filas
            winner = sign(sum(board(i, :)));
            return;
        elseif abs(sum(board(:, i))) == 3 % Revisa columnas
            winner = sign(sum(board(:, i)));
            return;
        end
    end
    % Revisa diagonales
    if abs(sum(diag(board))) == 3
        winner = sign(sum(diag(board)));
        return;
    elseif abs(sum(diag(flipud(board)))) == 3
        winner = sign(sum(diag(flipud(board))));
        return;
    end

    % Si no hay ganador
    winner = 0;
end