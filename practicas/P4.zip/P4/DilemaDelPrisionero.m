% Dilema del Prisionero en MATLAB
% Definir los pagos para las posibles acciones
% Matriz de pagos: [pago_A, pago_B]
payoffs = [
    -3, -3; % Ambos cooperan
    0, -10; % A traiciona, B coopera
    -10, 0; % A coopera, B traiciona
    -5, -5 % Ambos traicionan
];

% Acciones posibles
actions = {'Cooperar', 'Traicionar'};

% Elección de los jugadores (1 = Cooperar, 2 = Traicionar)
% Puedes cambiar estas elecciones para ver distintos resultados
choice_A = 1; % Elección del prisionero A
choice_B = 1; % Elección del prisionero B

% Determinar el pago según las elecciones
if choice_A == 1 && choice_B == 1
    outcome = payoffs(1, :); % Ambos cooperan
elseif choice_A == 2 && choice_B == 1
    outcome = payoffs(2, :); % A traiciona, B coopera
elseif choice_A == 1 && choice_B == 2
    outcome = payoffs(3, :); % A coopera, B traiciona
elseif choice_A == 2 && choice_B == 2
    outcome = payoffs(4, :); % Ambos traicionan
end

% Mostrar los resultados
disp(['Prisionero A elige: ', actions{choice_A}]);
disp(['Prisionero B elige: ', actions{choice_B}]);
disp(' ');
disp('Resultado (Años de cárcel para A, Años de cárcel para B): ');
disp(['(',num2str(outcome),')']);