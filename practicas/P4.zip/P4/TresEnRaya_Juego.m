function ticTacToeGame()
    % Crear la figura centrada en la pantalla
    screenSize = get(0, 'ScreenSize');
    figWidth = 400;
    figHeight = 500;
    fig = uifigure('Position', [(screenSize(3)-figWidth)/2, (screenSize(4)-figHeight)/2, figWidth, figHeight], 'Name', 'Tic-Tac-Toe');

    % Inicializa el tablero (0 = vacío, 1 = X, -1 = O)
    global board;
    board = [0 0 0; 0 0 0; 0 0 0];
    
    % Crear botones para el tablero
    global buttons;
    buttons = gobjects(3,3);
    
    % Crear los botones centrados en la ventana
    buttonSize = 100;
    startX = (figWidth - (3 * buttonSize)) / 2;
    startY = 200;
    
    for i = 1:3
        for j = 1:3
            buttons(i,j) = uibutton(fig, ...
                'Position', [startX + (j-1)*buttonSize, startY + (3-i)*buttonSize, buttonSize, buttonSize], ...
                'Text', '', ...
                'FontSize', 40, ...         % Tamaño de la fuente
                'FontWeight', 'bold', ...   % Negrita
                'FontColor', [0, 0, 1], ... % Color inicial de los botones
                'ButtonPushedFcn', @(btn, event) playerMove(i, j));
        end
    end
    
    % Crear la etiqueta de estado del juego centrada
    global statusLabel;
    statusLabel = uilabel(fig, 'Position', [startX, -200 + 3*buttonSize + 30, 300, 30], 'Text', 'Tu turno (X)', 'FontSize', 16, 'HorizontalAlignment', 'center');

    % Crear el botón de reinicio centrado
    restartButton = uibutton(fig, ...
        'Position', [(figWidth-100)/2, 20, 100, 30], ...
        'Text', 'Reiniciar', ...
        'ButtonPushedFcn', @(btn, event) restartGame());
end

% Función para el movimiento del jugador
function playerMove(row, col)
    global board buttons statusLabel;

    % Verifica si la casilla está vacía
    if board(row, col) == 0
        % Realiza el movimiento del jugador
        board(row, col) = 1;
        buttons(row, col).Text = 'X';
        buttons(row, col).FontColor = [0, 0, 1]; % Color de la 'X' (Azul)
        buttons(row, col).FontSize = 40;         % Tamaño de la 'X'
        buttons(row, col).FontWeight = 'bold';   % Negrita para la 'X'
        buttons(row, col).Enable = 'off';        % Desactiva el botón

        % Revisa si el jugador ha ganado
        if check_winner(board) == 1
            statusLabel.Text = '¡Ganaste!';
            disableBoard();
            return;
        elseif isempty(find(board == 0, 1))
            statusLabel.Text = '¡Empate!';
            disableBoard();
            return;
        end

        % Turno de la IA
        statusLabel.Text = 'Turno de la IA (O)';
        pause(1); % Pausa para que se vea el turno de la IA

        [~, aiMove] = minimax(board, -1); % Llama a minimax para el mejor movimiento de la IA
        board(aiMove(1), aiMove(2)) = -1;
        buttons(aiMove(1), aiMove(2)).Text = 'O';
        buttons(aiMove(1), aiMove(2)).FontColor = [1, 0, 0]; % Color de la 'O' (Rojo)
        buttons(aiMove(1), aiMove(2)).FontSize = 40;         % Tamaño de la 'O'
        buttons(aiMove(1), aiMove(2)).FontWeight = 'bold';   % Negrita para la 'O'
        buttons(aiMove(1), aiMove(2)).Enable = 'off';        % Desactiva el botón

        % Revisa si la IA ha ganado
        if check_winner(board) == -1
            statusLabel.Text = 'La IA ha ganado';
            disableBoard();
            return;
        elseif isempty(find(board == 0, 1))
            statusLabel.Text = '¡Empate!';
            disableBoard();
            return;
        end

        % Vuelve a habilitar el turno del jugador
        statusLabel.Text = 'Tu turno (X)';
    end
end

% Función Minimax (idéntica a la versión anterior)
function [score, move] = minimax(board, player)
    winner = check_winner(board);
    
    if winner ~= 0
        score = winner;
        move = [];
        return;
    elseif isempty(find(board == 0, 1))
        score = 0;
        move = [];
        return;
    end

    bestScore = -inf * player;
    bestMove = [];

    for i = 1:3
        for j = 1:3
            if board(i, j) == 0
                board(i, j) = player;
                [nextScore, ~] = minimax(board, -player);
                board(i, j) = 0;
                
                if (player == 1 && nextScore > bestScore) || (player == -1 && nextScore < bestScore)
                    bestScore = nextScore;
                    bestMove = [i, j];
                end
            end
        end
    end

    score = bestScore;
    move = bestMove;
end

% Función para revisar si hay un ganador
function winner = check_winner(board)
    % Comprobación de filas, columnas y diagonales
    for i = 1:3
        if abs(sum(board(i, :))) == 3 % Revisa filas
            winner = sign(sum(board(i, :)));
            return;
        elseif abs(sum(board(:, i))) == 3 % Revisa columnas
            winner = sign(sum(board(:, i)));
            return;
        end
    end
    % Revisa diagonales
    if abs(sum(diag(board))) == 3
        winner = sign(sum(diag(board)));
        return;
    elseif abs(sum(diag(flipud(board)))) == 3
        winner = sign(sum(diag(flipud(board))));
        return;
    end

    % Si no hay ganador
    winner = 0;
end

% Función para deshabilitar los botones del tablero
function disableBoard()
    global buttons;
    for i = 1:3
        for j = 1:3
            buttons(i,j).Enable = 'off';
        end
    end
end

% Función para reiniciar el juego
function restartGame()
    global board buttons statusLabel;
    
    % Vacía el tablero
    board = [0 0 0; 0 0 0; 0 0 0];
    
    % Restablece los botones
    for i = 1:3
        for j = 1:3
            buttons(i,j).Text = '';
            buttons(i,j).Enable = 'on';
        end
    end
    
    % Restablece el estado inicial del juego
    statusLabel.Text = 'Tu turno (X)';
end
